"""Application configuration."""

from shared.config.settings import Settings, get_settings

__all__ = ["Settings", "get_settings"]
